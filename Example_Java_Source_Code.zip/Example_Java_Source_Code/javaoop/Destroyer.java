/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaoop;
/**
 *
 * @author Gilles
 * 
 * Destroyer class that inherits from abstract Ship
 */
public class Destroyer extends Ship {
    
    private int numberMissile;
    
    public Destroyer()
    {
        this.length = 50;
        this.speed = 40;
        this.name = "New Destroyer";
        this.type = "A-class";
        this.numberMissile = 2;
    }

    public Destroyer(int len, int spd, String nam, String typ, int numMiss)
    {
        this.length = (len <= 0) ? 15 : len;
        this.speed = (spd <= 0) ? 0 : spd;
        this.name = (nam == null) ? "New Destroyer" : nam;
        this.type = (typ == null) ? "A-class" : typ;
        this.numberMissile = (numMiss <= 0) ? 0 : numMiss;
    }
    
    public Destroyer(int numMiss)
    {
        this.length = 50;
        this.name = "New Destroyer";
        this.speed = 40;
        this.type = "A-class";
        this.numberMissile = (numMiss <= 0) ? 0 : numMiss;
    }
    
    public int getNumberMissile() {
        return numberMissile;
    }
    
    public void setNumberMissile(int numberMissile) {
        this.numberMissile = numberMissile;
    }
    
    public void setNumberMissile(String numberMissile) {
        if (numberMissile == null) {
            System.out.println("Error: Input String is NULL.");
            System.out.println("Default number of missiles is 2");
            this.numberMissile = 2;
        }
        else {
            try {
                this.numberMissile = Integer.parseInt(numberMissile);
            }
            catch (NumberFormatException e)
            {
                this.numberMissile = 2;
                System.err.println("NumberFormatException: " + e.getMessage());
            }
        }
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 73 * hash + this.numberMissile;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Destroyer other = (Destroyer) obj;
        if (this.numberMissile != other.numberMissile) {
            return false;
        }
        return true;
    }
    
    @Override
    public String toString() {
        String outString = "Destroyer ID: " + hashCode() + "\n";
        outString += "Length: " + length + "  ";
        outString += "Speed: " + speed + "\n"; 
        outString += "Name: " + name + "\n";
        outString += "Type: " + type + "\n";
        outString += "Destroyer{" + "numberMissile=" + numberMissile + '}';
        return outString;
    }
    
}