/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaoop;

/**
 * 
 * @author Gilles
 * 
 * Abstract class for abstract Aircraft
 */
public class Aircraft implements Contact{
    int length;
    int speed;
    String name; 
    String type;
    int altitude;
    
    @Override
    public int getLength() {
        return length;
    }
    
    @Override
    public void setLength(int len) {
        this.length = (len <= 0) ? 10 : len;
    }
    
    @Override
    public int getSpeed() {
        return speed;
    }
    
    @Override
    public void setSpeed(int spd) {
        this.speed = (spd <= 0) ? 0 : spd;;
    }
    
    @Override
    public void setSpeed(String spd) {
        if (spd == null)
            System.out.println("Error: Input String is NULL");
        else
            this.speed = Integer.parseInt(spd);
    }
    
    @Override
    public String getName() {
        return name;
    }
    
    @Override
    public void setName(String nm) {
        this.name = nm;
    }
    
    @Override
    public String getType() { 
        return type;
    }
    
    @Override
    public void setType(String typ) {
        this.type = typ;
    }

    public int getAltitude() {
        return altitude;
    }

    public void setAltitude(int altitude) {
        this.altitude = altitude;
    }
}
