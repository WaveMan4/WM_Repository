/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaoop;

/**
 *
 * @author Gilles
 * 
 * Interface to be implemented for object properties/attributes
 */
public interface Contact {
    int getLength();
    void setLength(int len);
    int getSpeed();
    void setSpeed(int spd);
    void setSpeed(String spd);
    String getName();
    void setName(String nm);
    String getType();
    void setType(String typ);
}
