/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaoop;

/**
 *
 * @author Gilles
 * 
 * P3 class that inherits from abstract Aircraft
 */
public class P3 extends Aircraft {
    private int numberEngines; 
    
    public P3()
    {
        this.length = 36;
        this.speed = 46;
        this.name = "New P3";
        this.type = "C-class";
        this.numberEngines = 8;
    }

    public P3(int len, int spd, String nam, String typ, int numEng)
    {
        this.length = (len <= 0) ? 8 : len;
        this.speed = (spd <= 0) ? 0 : spd;
        this.name = (nam == null) ? "New P3" : nam;
        this.type = (typ == null) ? "E-class" : typ;
        this.numberEngines = (numEng <= 0) ? 0 : numEng;
    }
    
    public P3(int numEng)
    {
        this.length = 42;
        this.name = "New P3";
        this.speed = 88;
        this.type = "B-class";
        this.numberEngines = (numEng <= 0) ? 0 : numEng;
    }

    public int getNumberEngines() {
        return numberEngines;
    }

    public void setNumberEngines(int numberEngines) {
        this.numberEngines = numberEngines;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 23 * hash + this.numberEngines;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final P3 other = (P3) obj;
        if (this.numberEngines != other.numberEngines) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        String outString = "P3 ID: " + hashCode() + "\n";
        outString += "Length: " + length + "  ";
        outString += "Speed: " + speed + "\n"; 
        outString += "Name: " + name + "\n";
        outString += "Type: " + type + "\n";
        outString += "P3{" + "numberEngines=" + numberEngines + '}';
        return outString;
    }
    
    
}
