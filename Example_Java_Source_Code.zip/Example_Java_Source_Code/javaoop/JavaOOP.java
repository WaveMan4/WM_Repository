/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaoop;

import java.util.*;
/**
 *
 * @author Gilles
 */

public class JavaOOP {

    /**
     * @param args the command line arguments
     * 
     * By default, this program has zero (0) args
     */
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        // Step 1: Create 2 Destroyers
        Destroyer d1 = new Destroyer();
        Destroyer d2 = new Destroyer(40, 68, "Destroyer 2", "B-Class", 7);
        d1.setLength(50);
        d1.setSpeed(78);
        d1.setName("Destroyer 1");
        d1.setType("A-Class");
        d1.setNumberMissile("4");
        
        // Step 2: Create 2 Submarines
        Submarine s1 = new Submarine(7);
        Submarine s2 = new Submarine(46, 82, "Submarine 1", "B-Class", 11);
        s1.setNumberTorpedos("3");
        
        // Step 3: Create 2 P3s
        P3 p1 = new P3(48, 90, "P3 #1", "A-class", 10);
        P3 p2 = new P3(3);
        
        // Step 4: Make a collection of Destroyers (any type of Collection)
        Deque<Destroyer> destroyerDQ = new ArrayDeque<>();
        Destroyer d3 = new Destroyer(8);
        Destroyer d4 = new Destroyer(57, 82, "Custom #4", "E-Class", 2);
        Destroyer d5 = new Destroyer();
        d2.setName("First Destroyer in Array Deque");
        d5.setSpeed("Foo");
        d5.setName("Last Destroyer in Array Deque");
        destroyerDQ.offer(d1);
        destroyerDQ.offer(d3);
        destroyerDQ.offer(d4);
        destroyerDQ.offerLast(d5); 
        destroyerDQ.offerFirst(d2);
        
        // Step 5: Make a collection of Submarines (any type of Collection)
        HashSet submarineHashSet = new HashSet();
        Submarine s3 = new Submarine(62, 48, "Sub #3", "S-class", 6);
        Submarine s4 = new Submarine(4);
        s4.setSpeed(74);
        Submarine s5 = new Submarine(55, 94, "The Finale", "D-class", 12);
        submarineHashSet.add(s3);
        submarineHashSet.add(s1);
        submarineHashSet.add(s4);
        submarineHashSet.add(s2);
        submarineHashSet.add(s5);
        
        // Step 6: Make a collection that holds all Ships 
        s5.setName("Finale Re-loaded");
        d1.setSpeed("75");
        d4.setSpeed(54);
        s3.setNumberTorpedos(4);
        d3.setNumberMissile("ae4");
        d2.setNumberMissile("5");
        LinkedList<Ship> shipList = new LinkedList<>(); 
        shipList.add(d1);
        shipList.add(s3);
        shipList.add(s5);
        shipList.add(d4);
        shipList.add(d2);
        shipList.add(d3);
        
        // Step 7: Make a collections that holds all Contacts
        TreeMap<Integer, Contact> contactTree = 
               new TreeMap<>();
        p1.setName("Daedalus");
        p2.setName("Icarus");
        contactTree.put(1, p1);
        contactTree.put(2, d2);
        contactTree.put(3, d5);
        contactTree.put(4, s5);
        contactTree.put(5, s3);
        contactTree.put(6, d4);
        contactTree.put(7, p2);
        contactTree.put(8, d1);
        contactTree.put(9, s2);
        contactTree.put(10, d3);
        
        // Step 8.Print out the list of Contacts to System.out.println()
        System.out.println("Collection for Contacts: \n" + 
                                contactTree.toString() + "\n");
        
        p1.setName("First P3");
        p2.setName("Second P3");
        d5.setSpeed(-5);
        p2.setLength(-214);
        s3.setSpeed(-5);
        
        System.out.println("Collection for Contacts: \n" + 
                                contactTree.toString() + "\n");   
        
    }
    
}
