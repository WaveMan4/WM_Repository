/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaoop;

/**
 * 
 * @author Gilles
 * 
 * Abstract class for abstract Ship
 */
abstract class Ship implements Contact {
    int length;
    int speed;
    String name; 
    String type;
    
    @Override
    public int getLength() {
        return length;
    }
    @Override
    public void setLength(int len) {
        this.length = (len <= 0) ? 15 : len;
    }
    @Override
        public int getSpeed() {
        return speed;
    }
    @Override
    public void setSpeed(int spd) {
        this.speed = (spd <= 0) ? 0 : spd;
    }
    @Override
    public void setSpeed(String spd) {
        if (spd == null) {
            this.speed = 0;
            System.out.println("Error: Input String is NULL");
        }
        else {
            try {
                this.speed = Integer.parseInt(spd);
            }
            catch (NumberFormatException e)
            {
                this.speed = 0;
                System.err.println("NumberFormatException: " + e.getMessage());
            }
        }
            
        
    }
    public String getName() {
        return name;
    }
    public void setName(String nm) {
        this.name = nm;
    }
    public String getType() { 
        return type;
    }
    public void setType(String typ) {
        this.type = typ;
    }
}