/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaoop;

/**
 *
 * @author Gilles
 * 
 * Submarine class that inherits from abstract Ship
 */
public class Submarine extends Ship {
    private int numberTorpedos;
    
    public Submarine()
    {
        this.length = 50;
        this.speed = 40;
        this.name = "New Submarine";
        this.type = "A-class";
        this.numberTorpedos = 2;
    }

    public Submarine(int len, int spd, String nam, String typ, int numTorp)
    {
        this.length = (len <= 0) ? 14 : len;
        this.speed = (spd <= 0) ? 0 : spd;
        this.name = (nam == null) ? "New Submarine" : nam;
        this.type = (typ == null) ? "A-class" : typ;
        this.numberTorpedos = (numTorp <= 0) ? 0 : numTorp;
    }
    
    public Submarine(int numTorp)
    {
        this.length = 50;
        this.name = "New Submarine";
        this.speed = 40;
        this.type = "A-class";
        this.numberTorpedos = (numTorp <= 0) ? 0 : numTorp;
    }

    public int getNumberTorpedos() {
        return numberTorpedos;
    }

    public void setNumberTorpedos(int numberTorpedos) {
        this.numberTorpedos = numberTorpedos;
    }
    
    public void setNumberTorpedos(String numberTorpedos) {
        if (numberTorpedos == null) {
            System.out.println("Error: Input String is NULL.");
            System.out.println("Default number of torpedos is 2");
            this.numberTorpedos = 2;
        }
        else {
            try {
                this.numberTorpedos = Integer.parseInt(numberTorpedos);
            }
            catch (NumberFormatException e)
            {
                this.numberTorpedos = 2;
                System.err.println("NumberFormatException: " + e.getMessage());
            }
        }
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + this.numberTorpedos;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Submarine other = (Submarine) obj;
        if (this.numberTorpedos != other.numberTorpedos) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        String outString = "Submarine ID: " + hashCode() + "\n";
        outString += "Length: " + length + "  ";
        outString += "Speed: " + speed + "\n"; 
        outString += "Name: " + name + "\n";
        outString += "Type: " + type + "\n";
        outString += "Submarine{" + "numberTorpedos=" + numberTorpedos + '}';
        return outString;
    }

    
    
}
