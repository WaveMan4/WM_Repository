package kepnang.gilles.businesscard;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText fNameText;
    private EditText lNameText;
    private EditText streetText;
    private EditText cityText;
    private EditText stateText;
    private EditText zipCodeText;

    private TextView firstName;
    private TextView lastName;
    private TextView streetName;
    private TextView city;
    private TextView state;
    private TextView zipCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fNameText = findViewById(R.id.fNameText);
        lNameText = findViewById(R.id.lNameText);
        streetText = findViewById(R.id.streetNameText);
        cityText = findViewById(R.id.cityText);
        stateText = findViewById(R.id.stateText);
        zipCodeText = findViewById(R.id.zipcodeText);

        firstName = findViewById(R.id.fNameDisplay);
        lastName = findViewById(R.id.lNameDisplay);
        streetName = findViewById(R.id.streetNameDisplay);
        city = findViewById(R.id.cityDisplay);
        state = findViewById(R.id.stateDisplay);
        zipCode = findViewById(R.id.zipcodeDisplay);
    }

    public void updateDisplay(View view) {
        if (fNameText.getText().length() > 0 &&
                lNameText.getText().length() > 0 &&
                streetText.getText().length() > 0 &&
                cityText.getText().length() > 0 &&
                stateText.getText().length() > 0 &&
                zipCodeText.getText().length() > 0) {
            firstName.setText(fNameText.getText().toString());
            lastName.setText(lNameText.getText().toString());
            streetName.setText(streetText.getText().toString());
            city.setText(cityText.getText().toString() + ",");
            state.setText(stateText.getText().toString());
            zipCode.setText(zipCodeText.getText().toString());
        }
        else {
            Toast.makeText( getApplicationContext(),
                            "Please input all text fields",
                            Toast.LENGTH_SHORT).show();
        }
    }
}
