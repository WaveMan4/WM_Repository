#pragma once
#include "item.h"

class DeliverySlot
{
	public:
		DeliverySlot() {}
		Item returnedItem;
};