package com.gkepnan1.server;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import com.gkepnan1.client.GreetingService;
import com.gkepnan1.server.Rates;
import com.gkepnan1.server.Rates.HIKE;
import com.gkepnan1.server.BookingDay;
import com.gkepnan1.shared.FieldVerifier;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

/**
 * The server-side implementation of the RPC service.
 */
@SuppressWarnings("serial")
public class GreetingServiceImpl extends RemoteServiceServlet implements GreetingService {

	public String greetServer(Date startDate,
		 	int duration, 
			String hikeTrail, 
			String numPeople, 
			String name) throws IllegalArgumentException {
		
		// Verify that the inputs are valid.
		//Check Date
		if (!FieldVerifier.isValidDate(startDate)) {
			throw new IllegalArgumentException("Date must be valid");
		}
		//Check Duration
		if (duration <= 0) {
			throw new IllegalArgumentException("Duration must be valid");
		}
		//Check Hike Trail
		Rates instanceRates;
		if (hikeTrail == null) { 
			throw new IllegalArgumentException("Hike Trail must be valid");
        } 
        else {//Map Hiking Tour to Rates Class
            switch (hikeTrail) {
                case "Gardiner Lake":
                	instanceRates = new Rates(HIKE.GARDINER);
                    break;
                case "Hellroaring Plateau":
                	instanceRates = new Rates(HIKE.HELLROARING);
                    break;
                case "Beaten Path":
                	instanceRates = new Rates(HIKE.BEATEN);
                    break;
                default:
                	instanceRates = new Rates(HIKE.GARDINER);
                    break;
            }
        }
		//Check Number of People
		if (!FieldVerifier.isValidNumPeople(numPeople)) { 
			throw new IllegalArgumentException("Number of People must be valid");
		}	
		//Check name 
		if (!FieldVerifier.isValidName(name)) {
			// If the input is not valid, throw an IllegalArgumentException back to
			// the client.
			throw new IllegalArgumentException("Name must be at least 4 characters long");
		}
		// At this point we have confirmed that all input values are valid...
		
		///////////////////////////////////////////////////////
		//Now we calculate a total cost for the customer
		///////////////////////////////////////////////////////	
		//Parse the date -> obtain <year, month, day>
		String dateString = DateFormat.getDateInstance(DateFormat.SHORT).format(startDate);
		System.out.println(dateString);
		String dateArray[] = dateString.split("[/]+");

		int y = Integer.parseInt(dateArray[2]);
		int m = Integer.parseInt(dateArray[0]);
		int d = Integer.parseInt(dateArray[1]); 
		y += 2000;
		System.out.println("Year: " + y + " Month: " + m + " Day: " + d);
		//Create a Booking with the <year, month, day>
		BookingDay myBookingStart = new BookingDay(y, m, d);
		if (!myBookingStart.isValidDate()) {
			throw new IllegalArgumentException("Begin Date is not valid");
		}
        //***
		//	Assuming the date came from DateBox, we know that the date is valid...
		//***
		//Next we use the duration value for Booking
		BookingDay myBookingEnd = 
                new BookingDay(y, m, d + duration);
		if (!myBookingEnd.isValidDate()) {
			throw new IllegalArgumentException("End Date is not valid");
		}
        //Set Begin and End Dates
        instanceRates.setBeginDate(myBookingStart);
        instanceRates.setDuration(duration);
        instanceRates.setEndDate(myBookingEnd);
        //Determine total cost (multiplied by the number of people)
        double totalCost = instanceRates.getCost();
        double multiplier = Double.parseDouble(numPeople);
        totalCost *= multiplier; 
        totalCost = GreetingServiceImpl.round(totalCost, 2);
        
        //Determine transaction status
        String transactionStatus = "";
        if (totalCost >= 0) {
        	transactionStatus = "BHC Servlet transaction was successful.";
        }
        else {
        	transactionStatus = "BHC Servlet cannot provide cost for this.";
        }
        //Convert details of total cost to a STring
        String totalCostDetails = (Double.toString(totalCost));
		
        //PRINT OUT MESSAGE TO SERVER
		return "Hello, " + name + "!<br><br>" + 
				"For your BHC request, the transaction was " + transactionStatus + ".<br><br>" + 
				"The total cost is: " + "$" + totalCostDetails + "<br>";
	}
	
	private static double round(double value, int places) {
	    if (places < 0) throw new IllegalArgumentException();
	 
	    BigDecimal bd = new BigDecimal(Double.toString(value));
	    bd = bd.setScale(places, RoundingMode.HALF_UP);
	    return bd.doubleValue();
	}
}
