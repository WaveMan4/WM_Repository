package com.gkepnan1.client;

import java.util.Date;

import com.google.gwt.user.client.rpc.AsyncCallback;

/**
 * The async counterpart of <code>GreetingService</code>.
 */
public interface GreetingServiceAsync {
	void greetServer(Date startDate,
			int duration, 
			String hikeTrail, 
			String numPeople, 
			String name, 
			AsyncCallback<String> callback) throws IllegalArgumentException;
}
