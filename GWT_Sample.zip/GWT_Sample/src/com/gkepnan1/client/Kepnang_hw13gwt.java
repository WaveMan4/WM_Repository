package com.gkepnan1.client;

import java.util.Date;

import com.gkepnan1.shared.FieldVerifier;
import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyCodes;
import com.google.gwt.event.dom.client.KeyUpEvent;
import com.google.gwt.event.dom.client.KeyUpHandler;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.RadioButton;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.datepicker.client.DateBox;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class Kepnang_hw13gwt implements EntryPoint {
	/**
	 * The message displayed to the user when the server cannot be reached or
	 * returns an error.
	 */
	private static final String SERVER_ERROR = "An error occurred while "
			+ "attempting to contact the server. Please check your network " + "connection and try again.";

	private static final String[] TRAILS = { 	"Gardiner Lake", 
												"Hellroaring Plateau", 
												"Beaten Path"			};
	/**
	 * Create a remote service proxy to talk to the server-side Greeting service.
	 */
	private final GreetingServiceAsync greetingService = GWT.create(GreetingService.class);

	/**
	 * This is the entry point method.
	 */
	public void onModuleLoad() {		
		//////////////////////////////////////////
		// Listed below are GWT Widgets
		//////////////////////////////////////////
		//1) Start Date
		DateTimeFormat dateFormat = DateTimeFormat.getLongDateFormat();
		final DateBox dateBox = new DateBox();
		dateBox.setFormat(new DateBox.DefaultFormat(dateFormat));
		//2) Duration
		final RadioButton dur2 = new RadioButton("2");
		dur2.setText("2 days");
		final RadioButton dur3 = new RadioButton("3");
		dur3.setText("3 days");
		final RadioButton dur4 = new RadioButton("4");
		dur4.setText("4 days");
		final RadioButton dur5 = new RadioButton("5");
		dur5.setText("5 days");
		final RadioButton dur7 = new RadioButton("7");
		dur7.setText("7 days");
		//Enable radiobuttons by default
		dur3.setEnabled(true);
		dur5.setEnabled(true);
		dur2.setEnabled(false);
		dur4.setEnabled(false);
		dur7.setEnabled(false);
		//3) Hike Trail
		final ListBox hikeTrailBox = new ListBox(false);
		for (int i = 0; i < TRAILS.length; i++) {
			hikeTrailBox.addItem(TRAILS[i]);
		}
		hikeTrailBox.ensureDebugId("cwListBox-dropBox");
		//4) Number of People
		final TextBox numPeopleField = new TextBox();
		numPeopleField.setVisibleLength(4);
		numPeopleField.setMaxLength(4);
		numPeopleField.setText("");
		//5) Name
		final TextBox nameField = new TextBox();
		nameField.setText("");
		
		//-->SEND BUTTON to submit information
		final Button sendButton = new Button("Send");;
		final Label errorLabel = new Label();

		// We can add style names to widgets
		sendButton.addStyleName("sendButton");

		// Add the nameField and sendButton to the RootPanel
		// Use RootPanel.get() to get the entire body element
		RootPanel.get("startDateContainer").add(dateBox);
		RootPanel.get("durationContainer").add(dur2);
		RootPanel.get("durationContainer").add(dur3);
		RootPanel.get("durationContainer").add(dur4);
		RootPanel.get("durationContainer").add(dur5);
		RootPanel.get("durationContainer").add(dur7);
		RootPanel.get("hikeTrailContainer").add(hikeTrailBox);
		RootPanel.get("numPeopleContainer").add(numPeopleField);
		RootPanel.get("nameFieldContainer").add(nameField);
		RootPanel.get("sendButtonContainer").add(sendButton);
		RootPanel.get("errorLabelContainer").add(errorLabel);

		// Focus the cursor on the name field when the app loads
		nameField.setFocus(true);
		nameField.selectAll();

		// Create the popup dialog box
		final DialogBox dialogBox = new DialogBox();
		dialogBox.setText("Remote Procedure Call");
		dialogBox.setAnimationEnabled(true);
		final Button closeButton = new Button("Close");
		// We can set the id of a widget by accessing its Element
		closeButton.getElement().setId("closeButton");
		final HTML serverResponseLabel = new HTML();
		VerticalPanel dialogVPanel = new VerticalPanel();
		dialogVPanel.addStyleName("dialogVPanel");
		dialogVPanel.add(new HTML("<br><b>Server replies:</b>"));
		dialogVPanel.add(serverResponseLabel);
		dialogVPanel.setHorizontalAlignment(VerticalPanel.ALIGN_RIGHT);
		dialogVPanel.add(closeButton);
		dialogBox.setWidget(dialogVPanel);

		// Add a handler to close the DialogBox
		closeButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				dialogBox.hide();
				sendButton.setEnabled(true);
				sendButton.setFocus(true);
			}
		});

		// Create a handler for the sendButton and nameField
		class AdjustiveHandler implements ClickHandler {
			/**
			 * Fired when the user clicks on the sendButton.
			 */
			public void onClick(ClickEvent event) {
				if (event.getSource() == hikeTrailBox) {
					dur2.setChecked(false);
					dur3.setChecked(false);
					dur4.setChecked(false);
					dur5.setChecked(false);
					dur7.setChecked(false);
					if (hikeTrailBox.getSelectedIndex() == 0) {
						dur3.setEnabled(true);
						dur5.setEnabled(true);
						dur2.setEnabled(false);
						dur4.setEnabled(false);
						dur7.setEnabled(false);
					}
					if (hikeTrailBox.getSelectedIndex() == 1) {
						dur2.setEnabled(true);
						dur3.setEnabled(true);
						dur4.setEnabled(true);
						dur5.setEnabled(false);
						dur7.setEnabled(false);
					}
					if (hikeTrailBox.getSelectedIndex() == 2) {
						dur5.setEnabled(true);
						dur7.setEnabled(true);
						dur2.setEnabled(false);
						dur3.setEnabled(false);
						dur4.setEnabled(false);
					}
				}
			}
		}
		
		// Create a handler for the sendButton and nameField
		class MyHandler implements ClickHandler, KeyUpHandler {
			/**
			 * Fired when the user clicks on the sendButton.
			 */
			public void onClick(ClickEvent event) {
				sendParamsToServer();
			}

			/**
			 * Fired when the user types in the nameField.
			 */
			public void onKeyUp(KeyUpEvent event) {
				if (event.getNativeKeyCode() == KeyCodes.KEY_ENTER) {
					sendParamsToServer();
				}
			}

			/**
			 * Send the name from the nameField to the server and wait for a response.
			 */
			private void sendParamsToServer() {
				///////////////////////////////////////////////
				// First, we validate the input.
				///////////////////////////////////////////////
				//Check Date
				errorLabel.setText("");
				Date startDate = dateBox.getValue();
				if (!FieldVerifier.isValidDate(startDate)) {
					errorLabel.setText("Please enter your Start Date");
					return;
				}
				//Check Duration
				int duration = 0;
				if (dur2.isChecked()) { 
					duration = 2;
				}
				else if (dur3.isChecked()) { 
					duration = 3;
				}
				else if (dur4.isChecked()) { 
					duration = 4;
				}
				else if (dur5.isChecked()) { 
					duration = 5;
				}
				else if (dur7.isChecked()) { 
					duration = 7;
				}	  
				else {
					errorLabel.setText("Please enter a duration value");
	            	return;
				}
				//Check Hike Trail
				String hikeTrail = null; 
				hikeTrail = hikeTrailBox.getSelectedItemText();
	            if (hikeTrail == null) { 
	            	errorLabel.setText("Please enter your Hike Trail");
	            	return;
	            }
	            else {
	            	for (int i = 0; i < hikeTrailBox.getItemCount(); i++) { 
	            		if (hikeTrailBox.isItemSelected(i) == true) {
	            			break;
	            		}
	            	}
	            }
	            //Check Number of People
	            String numPeople = numPeopleField.getText();
	            if (!FieldVerifier.isValidNumPeople(numPeople)) { 
	            	errorLabel.setText("Number of People has to be greater than 0");
					return;
	            }
	            //Check Name
				String name = nameField.getText();
				if (!FieldVerifier.isValidName(name)) {
					errorLabel.setText("Please enter at least four characters");
					return;
				}

				// Then, we send the input to the server.
				sendButton.setEnabled(false);	//First disable send button on client-side
				serverResponseLabel.setText("");
				greetingService.greetServer(startDate, 
											duration, 
											hikeTrail, 
											numPeople, 
											name, 
											new AsyncCallback<String>() {
					public void onFailure(Throwable caught) {
						// Show the RPC error message to the user
						dialogBox.setText("Remote Procedure Call - Failure");
						serverResponseLabel.addStyleName("serverResponseLabelError");
						serverResponseLabel.setHTML(SERVER_ERROR);
						dialogBox.center();
						closeButton.setFocus(true);
					}

					public void onSuccess(String result) {
						// I left this in to show another debugging option...
						System.out.println("Result = " + result);
						dialogBox.setText("Remote Procedure Call");
						serverResponseLabel.removeStyleName("serverResponseLabelError");
						serverResponseLabel.setHTML(result);
						dialogBox.center();
						closeButton.setFocus(true);
					}
				});
			}
		}
		
		// Add a handler to adjust radioButton enablers
		AdjustiveHandler adjHandler = new AdjustiveHandler();
		hikeTrailBox.addClickHandler(adjHandler);		
		// Add a handler to send the name to the server
		MyHandler handler = new MyHandler();
		sendButton.addClickHandler(handler);
		numPeopleField.addKeyUpHandler(handler);
		nameField.addKeyUpHandler(handler);		
	}
}
