//Name: Gilles Kepnang

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <QString>
#include <QFile>
#include <QtCore>
#include <QTextStream>

//global variables for reading inputs from files
QList <double> matrix1, matrix2;
//Struct used for each input matrix
struct file_data
{
   int	thread_id;
   int rows;
   int cols;
   QString cur;
   QList<double> *matrix;
};
//Struct used for each output matrix
struct out_data
{
    int row;
    int col;
    double sum;
};

struct file_data fdata1;    //Struct for input file 1
struct file_data fdata2;    //Struct for input file 2
struct out_data output;   //Struct for output file
int row1, row2, col1, col2; //Variables for rows and columns from input files
int error;
//Threaded function for creating the matrix based on input files
void *createMatrix(void *fthread)
{
    //Assign struct pointer to current struct arg
    struct file_data *fptr;
    fptr = (struct file_data *) fthread;
    //Initialize variables necessary to read values from file
    //into the struct
    QStringList numlist;
    QString test;
    QString filename = (fptr->cur);
    QFile file(filename);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        printf("Error: File doesn't exist!\n");
        pthread_exit(NULL);
    }
    QTextStream in(&file);
    double input;
    bool ok;
    while (!in.atEnd())
    {   //Read in values and split numbers appropriately
        numlist = in.readLine().split(" ");
        //Generate row values and column values
        //Append values list of floats for matrix
        fptr->cols = numlist.size();
        for (int i=0; i < numlist.size(); i++)
        {
            test = numlist.at(i);
            input = test.toInt(&ok,10); //Check for int
            if (!ok)
            {
                input = (test.toFloat(&ok));    //Check for float
                if (ok) fptr->matrix->append(input);
                else
                {
                    printf("Error: Invalid number found in file!\n");
                    error = 1;
                    pthread_exit(NULL);
                }
            }
            else fptr->matrix->append((int)input);
        }
        fptr->rows++;
    }
    printf("Finishing thread %d\n", fptr->thread_id);
    //Assign values row and columns in matrix 1 and matrix 2
    if (fptr->thread_id == 1)   {   row1 = fptr->rows; col1 = fptr->cols;   }
    if (fptr->thread_id == 2)   {   row2 = fptr->rows; col2 = fptr->cols;   }
    pthread_exit(NULL);
}

//Threaded function for matrix multiplication based on input files
void *matMult(void *othread)
{
    //Assign struct pointer to current struct arg
    struct out_data *optr;
    optr = (struct out_data *) othread;
        //Create result matrix with product matrix
        //Algorithm is used with consideration that linear Qlist containers
        //hold all values for different row and column locations
        //"m1_ind" and "m2_ind" represent indices for the global
        //matrices matrix and matrix 2
        int m1_ind(0), m2_ind(0);
        double sum(0);
        m1_ind = (optr->row) * col1;
        m2_ind = optr->col;
        for (int i=0; i < col1; i++)
        {
            //Matrix Multiplication happens here for each element
            //of the output matrix...
            sum += (matrix1[m1_ind] * matrix2[m2_ind]);
            m2_ind += col2;
            m1_ind++;
        }
        optr->sum = sum;
    printf("Finishing thread %d\n", (optr->row) * row1 + (optr->col));
    pthread_exit((void *) 0);     //Exit function
}

/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
/*                                  MAIN FUNCTION                              */
/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
int main (int argc, char *argv[])
{
    try //Try-and-catch system for exception handling
    {
        if (argc == 4)
        {
            //Assign argument values to variables for potential file-opening
            QString a = argv[1]; QString  b = argv[2]; QString  c = argv[3];
            QFile file_a(a);    QFile file_b(b);    QFile file_c(c);
            //Check if each file exists
            if (!file_a.exists()) throw 2;
            if (!file_b.exists()) throw 3;            
            if (!file_c.open(QIODevice::WriteOnly | QIODevice::Text))
            {
                printf("Error: File doesn't exist!\n");
                return 0;
            }

            //Create threads to read from input file 1 and 2
            pthread_t filethread1, filethread2;
            int rc, status;

    //////* Initialize struct and establish thread for file 1 */////
            fdata1.thread_id = 1;
            fdata1.cur = a;
            fdata1.matrix = &matrix1;
            printf("Creating filethread %d\n", fdata1.thread_id);
            rc = pthread_create(&filethread1, NULL, createMatrix, (void *)&fdata1);
            if (rc)
            {
               printf("ERROR; return code from pthread_create() is %d\n", rc);
               exit(-1);
            }
    ///////////////////////////////////////////////////////////////

    /* Initialize struct and establish thread for file 2 */
            fdata2.thread_id = 2;
            fdata2.cur = b;
            fdata2.matrix = &matrix2;
            printf("Creating filethread %d\n", fdata2.thread_id);
            rc = pthread_create(&filethread2, NULL, createMatrix, (void *)&fdata2);
            if (rc)
            {
               printf("ERROR; return code from pthread_create() is %d\n", rc);
               exit(-1);
            }
    ////////////////////////////////////////////////////////////
    /////////////* Wait until filethread1 has been finished
            rc = pthread_join(filethread1, (void **)&status);
            if (rc)
            {
               printf("ERROR return code from pthread_join() is %d\n", rc);
               exit(-1);
            }
            printf("Completed join with thread %d status= %d\n",1, status);

            //Check error flag before generating output:
            if (error == 1) pthread_exit(NULL);
    /////////////* Wait until filethread2 has been finished
            rc = pthread_join(filethread2, (void **)&status);
            if (rc)
            {
               printf("ERROR return code from pthread_join() is %d\n", rc);
               exit(-1);
            }
            printf("Completed join with thread %d status= %d\n",2, status);
    //System waits until pthread_join functions are returned from

            //Check error flag before generating output:
            if (error == 1) pthread_exit(NULL);
    //////////////////////////////////////////////////////////////////
    /////////* Establish "thread matrix" for output file *////////////

    //Initialize variables necessary to write
    //matrix multiplication values to output file
            if (col1 == row2)
            {
                //Create matrices based on matrix sizes read in file
                const int R = row1, C = col2;
                pthread_t thread_arr[R][C];
                out_data output[R][C];
    /* For the production of threads, I used the pthread_create function to generate the threads
   and multiply different values at different positions within the output matrix. Doing this
   in a "for loop" would create all the necessary threads for each value. I used the attributes
   to allow for threads to finish before the program is exited. This is used here because a
   higher volume of threads are created.
   There was no need for mutex or semaphores because all threads should be able to run in
   parallel and independently as well. Acknowledgement signals and "handshakes" are not necessary.
    */
                /* Initialize and set thread detached attribute */
                pthread_attr_t attr;
                pthread_attr_init(&attr);
                pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
                //Create threads for output matrix element
                for (int i=0; i<R; i++)
                {
                    for (int j=0; j<C; j++)
                    {
                        //Assign necessary values for 2d struct
                        output[i][j].row = i;
                        output[i][j].col = j;
                        output[i][j].sum = 0;
                        printf("Creating thread %d\n", (i*row1)+j+1);
                        rc = pthread_create( &thread_arr[i][j], &attr, matMult, (void *)
                             &output[i][j]);
                        if (rc) {
                          printf("ERROR; return code from pthread_create() is %d\n", rc);
                          exit(-1);
                          }
                    }
                }

                /* Free attribute and wait for the other threads */
                pthread_attr_destroy(&attr);
                //pthread_join function allows all threads to run until they are finished
                for (int i=0; i<R; i++)
                {
                    for (int j=0; j<C; j++)
                    {
                        rc = pthread_join(thread_arr[i][j], (void **)&status);
                        if (rc) {
                            printf("ERROR return code from pthread_join() is %d\n", rc);
                            exit(-1);
                         }
                        printf("Completed join with thread %d status= %d\n",(i*row1)+j+1,status);
                    }
                }

               //Output result matrix to thread argument (output file)
               QTextStream out(&file_c);
               QString str;
               for (int i=0; i < row1; i++)
               {
                   bool ok;
                   for (int j=0; j < col2; j++)
                   {
                       str = QString::number(output[i][j].sum);
                       str.toInt(&ok, 10);
                       if (!ok) //Check if value is an int
                       {
                           str.toFloat(&ok);    //Check if value is a float
                           if (ok) out << QString::number(output[i][j].sum, 'f', 4);
                           else
                           {
                               printf("Error: Invalid number found in file!\n");
                               error = 1;
                               pthread_exit(NULL);
                           }
                       }
                       else out << QString::number((int)output[i][j].sum,10);
                        //Condition used to improve formatting
                       if (j != (col2-1)) out << "\t";
                   }
                   out << "\n";
               }
            }
            else throw 4;

        }
        else throw 1;
    }
    catch (int e)   //Catch block for errors
    {
        if (e == 1) printf("Error: Invalid number of args \n");
        if (e == 2) printf("Error: File assumed for input a doesn't exist\n");
        if (e == 3) printf("Error: File assumed for input b doesn't exist\n");
        if (e == 4) printf("Error: Invalid sizes for matrices from input file\n");
    }
    pthread_exit(NULL); //Exit from main
}
////////////////////////////////////////////////////////////////////////////////
/*                          END OF MAIN FUNCTION                              */
////////////////////////////////////////////////////////////////////////////////
