/**
 * @author Gilles K.
 * @version 1.0
 * Displays a panel for the MP3 Player
 */

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import javafx.event.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;

public class displayPanel extends GridPane  //Change to GridPane
{
    private Label songLabel, itemLabel, 
        descripLabel, artistLabel, 
        albumLabel, priceLabel;
    private ComboBox<String> songBox;
    private TextField itemText,
        descripText, artistText, 
        albumText, priceText;
    private Button addButton, editButton, 
        deleteButton, acceptButton, 
        cancelButton, exitButton;
    private HashMap <String, MP3File> audioFiles;
    private Label statusLabel;
    private boolean add, edit;
    
    private Scanner in;
    
    private String dbFileName;
    
    //////////////////////////////////////////////
    //               CONSTRUCTOR                //
    //////////////////////////////////////////////
    public displayPanel(String fileName)
    {
        //Initialize Handlers
        ButtonPush BP_Handler = new ButtonPush();
        ComboBoxSelect CBS_Handler = new ComboBoxSelect();
        
        //Create new Hashmap
        audioFiles = new HashMap <String, MP3File>();
        
        //Add Labels
        songLabel = new Label("Select Song: ");
        itemLabel = new Label("Item Code: ");
        descripLabel = new Label("Description: ");
        artistLabel = new Label("Artist: ");
        albumLabel = new Label("Album: ");
        priceLabel = new Label("Price: ");
        
        statusLabel = new Label();
        
        //Add Combo Box for a list of songs
        songBox = new ComboBox<String>();

        //Add TextFields
        itemText = new TextField();
        descripText = new TextField();
        artistText = new TextField();
        albumText = new TextField();
        priceText = new TextField();

        //Add Buttons        
        addButton = new Button("Add"); 
        editButton = new Button("Edit"); 
        deleteButton = new Button("Delete");  
        acceptButton = new Button("Accept");  
        cancelButton = new Button("Cancel");  
        exitButton = new Button("Exit"); 
        
        //Connect Objects to Handler
        addButton.setOnAction(BP_Handler);
        editButton.setOnAction(BP_Handler);
        deleteButton.setOnAction(BP_Handler);  
        acceptButton.setOnAction(BP_Handler);
        cancelButton.setOnAction(BP_Handler);
        exitButton.setOnAction(BP_Handler);
        
        songBox.setOnAction(CBS_Handler);
        
        //Place Buttons in a Grid Layout
        FlowPane buttonPane = new FlowPane();
        buttonPane.getChildren().add(addButton);
        buttonPane.getChildren().add(editButton);
        buttonPane.getChildren().add(deleteButton);
        buttonPane.getChildren().add(acceptButton);
        buttonPane.getChildren().add(cancelButton);
        buttonPane.getChildren().add(exitButton);
        
        //Add all objects to GridPane
        this.add(songLabel,1,2);
        this.add(itemLabel,1,3);
        this.add(descripLabel,1,4);
        this.add(artistLabel,1,5);
        this.add(albumLabel,1,6);
        this.add(priceLabel,1,7);
        
        this.add(songBox,2,2);
        this.add(itemText,2,3);
        this.add(descripText,2,4);
        this.add(artistText,2,5);
        this.add(albumText,2,6);
        this.add(priceText,2,7);
        
        this.add(buttonPane,2,10); 

        //Set all mode flags to false
        add = false;
        edit = false; 
        
        //Open Database based on fileName
        setDbFileName(fileName);
        makeDatabaseWith(fileName);
        
        
        //Display original state frame
        original_disp_state();
        
    }
    
    //////////////////////////////////////////////
    //    SETUP FUNCTIONS FOR DB AND MP3FILES   //
    //////////////////////////////////////////////
    /**
     * Process data (for a requested .dat database into HashMap) 
     * 
     * @param fileName: input file for song database
     * 
     */
    public void makeDatabaseWith(String fileName)
    {
        in = new Scanner(System.in);
        
        //Phase 1: Test if file exists
        try (FileReader inFileReader = new FileReader(fileName))
        {
            String curLine;
            String [] words;
            Scanner fileIn = new Scanner(inFileReader);
            
            //If so, read info from File
            while (fileIn.hasNext())
            {
                curLine = fileIn.nextLine();
                words = curLine.split("[|]");
                if (words.length == 6)
                {
                    System.out.print(words[0] + " ");               
                    System.out.print(words[1] + " ");
                    System.out.print(words[2] + " ");
                    System.out.print(words[3] + " ");
                    System.out.print(words[4] + " ");
                    System.out.print(words[5] + "\n");
 
                    MP3File aNewFile = new MP3File();
                    aNewFile.setSongInfo(words[0]);
                    aNewFile.setItemCode(words[1]);
                    aNewFile.setsongDescripInfo(words[2]);
                    aNewFile.setArtistInfo(words[3]);
                    aNewFile.setAlbumInfo(words[4]);
                    aNewFile.setPriceInfo(words[5]);
                    
                    addToMapAndDisplay(aNewFile);
                }
            }
            
            fileIn.close();
            
        }
        catch (FileNotFoundException fnfe)
        {
            //If file does not exist, check if file should be created
            System.out.println("File has not been found.");
            System.out.println("Do you want to create a new File with this name? ");
            System.out.print("\t\tPress y or n (for 'yes' or 'no'): ");
            String userIn;
            userIn = in.next();
            if (userIn.charAt(0) == 'y') //if user selects 'yes', create a file for output
            {
                //"try" block for FileWriter will open a new file
                try (FileWriter outFile = new FileWriter(fileName))
                {                
                }
                catch (IOException ioe) //If IO Exception happens, exit program altogether
                {
                    System.out.print("IO Exception Found: ");
                    System.out.print(ioe.getMessage() + "\n");
                    System.exit(0);
                }
                return;
            }
            else if (in.next().charAt(0) == 'n') //If user selects 'no', exit program altogether
            {
                System.out.println("According to user input, program cannot proceed.");
                System.out.println("EXITING NOW");
                System.exit(0);
            }
            
            //If user did not select yes or no, lock in this while loop...
            //  until user selects appropriately
            while (userIn.charAt(0) != 'y' && userIn.charAt(0) != 'n')
            {
                userIn = in.next();
                if (userIn.charAt(0) == 'y') 
                {
                    //if user selects 'yes', create a file for output
                    try (FileWriter outFile = new FileWriter(fileName))
                    {
                        
                    }
                    catch (IOException ioe)
                    {
                        System.out.print("IO Exception Found: ");
                        System.out.print(ioe.getMessage() + "\n");
                        System.exit(0);
                    }
                    return;
                }
                else if (in.next().charAt(0) == 'n') //If user selects 'no', exit program altogether
                {
                    System.out.println("According to user input, program cannot proceed.");
                    System.out.println("EXITING NOW");
                    System.exit(0);
                }
            }
        }
        catch (IOException e) //If IO Exception happens, exit program altogether
        {
            System.out.print("IO Exception Found: ");
            System.out.print(e.getMessage() + "\n");
            System.exit(0);
        }
        
        in.close(); //Close system input scanner
    }
    
    
    //////////////////////////////////////////////
    //          ACCESSOR FUNCTIONS              //
    //////////////////////////////////////////////
    /**
     * Setter method for dbFileName 
     * @param dbFileName: database file name
     */
    public void setDbFileName(String dbFileName) 
    {
        this.dbFileName = dbFileName;
    }
    
    /**
     * Getter method for dbFileName
     * @return: string value for database filename 
     */
    public String getDbFileName() 
    {
        return dbFileName;
    }
    
    /**
     * Add an MP3File object to HashMap and display MP3File in ComboBox
     * 
     * @param fileToAdd: MP3 file to be stored and displayed
     */
    public void addToMapAndDisplay(MP3File fileToAdd)
    {
        //Add MP3file to Map
        this.audioFiles.put(fileToAdd.getsongDescripInfo(), fileToAdd);
        
        //Add MP3 song to Song ComboBox
        songBox.getItems().add(fileToAdd.getsongDescripInfo());
    }
    
    //////////////////////////////////////////////
    //    HANDLER CLASSES FOR ACTION-EVENTS     //
    //////////////////////////////////////////////

    //Handler for "Button Push"
    class ButtonPush implements EventHandler<ActionEvent>
    {
        public void handle( ActionEvent e )
        {
            Object source = e.getSource();
            if (source == addButton)
            {
                //Activate 'add' mode
                add = true;
                
                //  Clear and enable the Item Code, 
                //      Description, Artist, Album, and Price fields
                itemText.setDisable(false);
                descripText.setDisable(false);
                artistText.setDisable(false);
                albumText.setDisable(false);
                priceText.setDisable(false);
                
                itemText.setText("");
                descripText.setText("");
                artistText.setText("");
                albumText.setText("");
                priceText.setText("");
                
                //  Also disable Edit and Delete buttons
                addButton.setDisable(true);
                editButton.setDisable(true);
                deleteButton.setDisable(true);
                
                //  And enable Accept and Cancel buttons
                acceptButton.setDisable(false);
                cancelButton.setDisable(false);
            }
            else if (source == editButton)
            {
                edit = true;
                descripText.setDisable(false);
                artistText.setDisable(false);
                priceText.setDisable(false);
                
                addButton.setDisable(true);
                editButton.setDisable(true);
                deleteButton.setDisable(true);
                acceptButton.setDisable(false);
                cancelButton.setDisable(false);
                
            }
            else if (source == deleteButton)
            {
                deleteSong();
                
            }
            else if (source == acceptButton)
            {
                if (add)
                {
                    acceptBasedOnAdd();
                }
                else if (edit)
                {
                    acceptBasedOnEdit();
                }
                else return;
            }
            else if (source == cancelButton)
            {
                if (add)
                {
                    cancelBasedOnAdd();
                }
                else if (edit)
                {
                    cancelBasedOnEdit();
                }
                else return;
            }
            else if (source == exitButton)
            {
                writeDataToFile();
                System.exit( 0 );
            }
        } 
    }
    
    //Handler for "ComboBox Select"
    class ComboBoxSelect implements EventHandler<ActionEvent>
    {
        public void handle( ActionEvent e )
        {
            Object source = e.getSource();
            if (source == songBox)
            {
                String currSong = songBox.getSelectionModel().getSelectedItem();
                MP3File foundFile = audioFiles.get(currSong);
                itemText.setText(foundFile.getItemCode());
                descripText.setText(foundFile.getsongDescripInfo());
                artistText.setText(foundFile.getArtistInfo());
                albumText.setText(foundFile.getAlbumInfo());
                priceText.setText(foundFile.getPriceInfo());
            }
        } 
    }
    
    //////////////////////////////////////////////
    //             MEMBER FUNCTIONS             //
    //////////////////////////////////////////////
    public void original_disp_state()
    {
        //SongBox is either empty or displaying the first song
        //Make other textfields disabled (non-editable)
        this.itemText.setDisable(true);
        this.descripText.setDisable(true);
        this.artistText.setDisable(true);
        this.albumText.setDisable(true);
        this.priceText.setDisable(true);
        
        if (songBox.getItems().size() == 0)
        {   //if SongBox is empty, make textfields blank
            //      and make "Add" and "Edit" enabled; 
            //      disable the rest
            itemText.setText("");
            descripText.setText("");
            artistText.setText("");
            albumText.setText("");
            priceText.setText("");
            
            addButton.setDisable(false);
            editButton.setDisable(false);
            deleteButton.setDisable(true);
            exitButton.setDisable(true);
            acceptButton.setDisable(true);
            cancelButton.setDisable(true);
                      
        }
        else
        {   //if SongBox is not empty, display the first song
            //  and make "Add", "Edit", "Delete", "Exit" enabled; 
            //  disable "Accept" and "Cancel"
            addButton.setDisable(false);
            editButton.setDisable(false);
            deleteButton.setDisable(false);
            exitButton.setDisable(false);
            acceptButton.setDisable(true);
            cancelButton.setDisable(true);
        }
    }
    
    /**
     * Check text fields and ensure requirements are appropriate
     * @return boolean value indicating that appropriate values were input
     */
    public boolean checkTextFields()
    {
        boolean item, desc, artist, album, price;
        item = (this.itemText.getText().length() > 0);
        desc = (this.descripText.getText().length() > 0);
        artist = (this.artistText.getText().length() > 0);
        album = (this.albumText.getText().length() > 0);
        price = (this.priceText.getText().length() > 0);
        
        //Requirements for database addition: 
        //  Must have a Song name filled out
        //  Must have at least one other field filled out
        return (item & (desc | artist | album | price));
    }
    
    /**
     * Checks if song already exists in ComboBox
     * @param currSong: input String with song name
     * 
     * @return boolean value indicating that song "exists" or "does not exist"
     */
    public boolean songAlreadyExists(String currSong)
    {
        String refSong;
        for (int comboIter = 0; comboIter < songBox.getItems().size(); comboIter++)
        {
            refSong = (String)songBox.getItems().get(comboIter);
            if (refSong.equals(currSong))
            {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Accepts user input based on the "Add" action
     */
    public void acceptBasedOnAdd()
    {
        //Check for empty Combo Box
        String currSong;
        if (descripText.getText().length() > 0)
        {
            currSong = (String) this.descripText.getText();
        }
        else
        {
            this.statusLabel.setText("Error: MP3 song needs a song name");
            return;
        }
        
        //Check for the following requirements: 
        //  1)If current song is same as previous
        //  2)If all appropriate field as checked
        //  3)If other fields needs to be filled out
        if (songAlreadyExists(currSong))
        {
            this.statusLabel.setText("Error: Song name already exists. Type another");
            return;
        }
        else if (checkTextFields() == true) //Check if all fields are filled up
        {
            //Add song to database
            MP3File aNewFile = new MP3File(); 
            aNewFile.setItemCode(this.itemText.getText());
            aNewFile.setsongDescripInfo(this.descripText.getText());
            aNewFile.setArtistInfo(this.artistText.getText());
            if (this.albumText.getText().length() > 0)
            {
                if (this.albumText.getText().equals(""))
                {
                    aNewFile.setAlbumInfo("None");
                }
                else
                {
                    aNewFile.setAlbumInfo(this.albumText.getText());
                }
            }
            else 
            {
                aNewFile.setAlbumInfo("None");
            }
            
            if (this.priceText.getText().length() > 0)
            {
                if (this.priceText.getText().length() == 0)
                {
                    aNewFile.setPriceInfo("0.00");
                }
                else
                {
                    aNewFile.setPriceInfo(this.priceText.getText());
                }
            }
            else
            {
                aNewFile.setPriceInfo("0.00");
            }
            
            System.out.println("Properties for the added Song: ");
            System.out.println("\tSong: " + aNewFile.getsongDescripInfo());
            System.out.println("\tItemCode: " + aNewFile.getItemCode());
            System.out.println("\tDescription: " + aNewFile.getsongDescripInfo());
            System.out.println("\tArtist: " + aNewFile.getArtistInfo());
            System.out.println("\tAlbum: " + aNewFile.getAlbumInfo());
            System.out.println("\tPrice: " + aNewFile.getPriceInfo());
            
            //add key and values to HashMap
            addToMapAndDisplay(aNewFile);
          
            System.out.println("\nSONG LIST: \n");
            for (Map.Entry song : audioFiles.entrySet())
            {
                System.out.println("key: " + song.getKey());
            }
            
            //disable mode
            add = false;
            
            //provide default status message
            
            //return to original state
            original_disp_state();
        }
        else 
        {
          //Wait until appropriate info is provided
          System.out.println("Error: Info is still required");
          statusLabel.setText("Error: Info is still required");
        }
    }
    
    /**
     * Accepts user input based on the "Edit" action
     */
    public void acceptBasedOnEdit()
    {
        String currSong = this.descripText.getText();
        
        if (checkTextFields() == true) //Check required filed
        {
            MP3File aNewFile = this.audioFiles.get(currSong);
            aNewFile.setItemCode(this.itemText.getText());
            aNewFile.setsongDescripInfo(this.descripText.getText());
            aNewFile.setArtistInfo(this.artistText.getText());
            aNewFile.setAlbumInfo(this.albumText.getText());
            aNewFile.setPriceInfo(this.priceText.getText());
            
            //place value (object) back into HashMap based on key
            this.audioFiles.put(currSong, aNewFile);
            
            //disable mode
            this.edit = false;
            
            //return to original state
            original_disp_state();         
        }
        else 
        {//Wait until appropriate info is provided
           this.statusLabel.setText("Error: At least 1 extra info is required");
        }
    }
    
    /**
     * Cancel user input during the "Add" action
     */
    public void cancelBasedOnAdd()
    {
        
        //return to original state
        original_disp_state();
        
        //disable mode
        this.add = false;
        
    }
    
    /**
     * Cancel user input during the "Edit" action
     */
    public void cancelBasedOnEdit()
    {
        
        //return to original state
        original_disp_state();
        
        //disable mode
        this.edit = false;
        
        //Revert to prior values
        String currSong = songBox.getSelectionModel().getSelectedItem();
        MP3File foundFile = audioFiles.get(currSong);
        itemText.setText(foundFile.getItemCode());
        descripText.setText(foundFile.getsongDescripInfo());
        artistText.setText(foundFile.getArtistInfo());
        albumText.setText(foundFile.getAlbumInfo());
        priceText.setText(foundFile.getPriceInfo());
    }
    
    /**
     * Deletes song from HashMap and ComboBox based on "Delete" action
     */
    public void deleteSong()
    {
        String currSong = (String) songBox.getSelectionModel().getSelectedItem();
        if (checkTextFields() == true) 
        {
            System.out.println("Song to Delete:" + currSong);
            System.out.println("HashMap Size BEFORE: " + audioFiles.size());
            
            //Remove song from HashMap
            this.audioFiles.remove(currSong);
            System.out.println("HashMap Size AFTER: " + audioFiles.size());
            
            System.out.println("Combobox Size BEFORE: " + songBox.getItems().size());
            //Remove song from comboBox
            songBox.getItems().remove(currSong);
            System.out.println("Combobox Size AFTER: " + songBox.getItems().size());
            
            //return to original state
            original_disp_state();
        }
    }
    
    
    
    
    
    /**
     * Writes data from HashMap to an output file
     */
    public void writeDataToFile()
    {
      //Write info to file Database
        try (FileWriter output = new FileWriter(this.dbFileName))
        {                
            output.write("LIST OF SONGS FROM DATABASE\n");
            output.write("---------------------------\n");
            
            MP3File currFile;
            for (Map.Entry <String, MP3File> foundFile : this.audioFiles.entrySet() )
            {
                currFile = foundFile.getValue();
                output.write(currFile.getSongInfo() + "|");
                output.write(currFile.getItemCode() + "|");
                output.write(currFile.getsongDescripInfo() + "|");
                output.write(currFile.getArtistInfo() + "|");
                output.write(currFile.getAlbumInfo() + "|");
                output.write(currFile.getPriceInfo() + "\n");
            }
            System.out.println("Songs have been written to " + this.dbFileName);
        }
        catch (IOException ioe) //If IO Exception happens, exit program altogether
        {
            System.out.print("IO Exception Found: ");
            System.out.print(ioe.getMessage() + "\n");
            System.exit(0);
        }
    }
}
