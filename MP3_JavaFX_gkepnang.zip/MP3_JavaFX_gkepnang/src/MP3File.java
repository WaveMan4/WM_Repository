/**
 * @author Gilles K.
 * @version 1.0
 * 
 */

public class MP3File 
{
    private String songInfo;
    private String itemCode;
    private String songDescripInfo;
    private String artistInfo;
    private String albumInfo;
    private String priceInfo;
    
    //////////////////////////////////////////////
    //              CONSTRUCTORS                //
    //////////////////////////////////////////////
    /**
     * Default Constructor
     */
    public MP3File()
    {
        
    }
    
    //////////////////////////////////////////////
    //          ACCESSOR FUNCTIONS              //
    //////////////////////////////////////////////
    /**
     * Getter method for songInfo 
     * @return: string value for song info
     */
    public String getSongInfo()
    {
        return songInfo;
    }

    /**
     * Setter method for songInfo 
     * @param songInfo: song information
     */
    public void setSongInfo(String songInfo) 
    {
        this.songInfo = songInfo;
    }

    /**
     * Getter method for songDescripInfo
     * @return: string value for description info 
     */
    public String getsongDescripInfo() 
    {
        return songDescripInfo;
    }

    /**
     * Setter method for descripInfo 
     * @param descripInfo: description information
     */
    public void setsongDescripInfo(String descripInfo) 
    {
        this.songDescripInfo = descripInfo;
    }

    /**
     * Getter method for itemCode 
     * @return: string value for item code
     */
    public String getItemCode() 
    {
        return itemCode;
    }

    /**
     * Setter method for itemCode 
     * @param itemCode: item code information
     */
    public void setItemCode(String itemCode) 
    {
        this.itemCode = itemCode;
    }

    /**
     * Getter method for artistInfo 
     * @return: string value for artist info
     */
    public String getArtistInfo() 
    {
        return artistInfo;
    }

    /**
     * Setter method for artistInfo 
     * @param artistInfo: artist information
     */
    public void setArtistInfo(String artistInfo) 
    {
        this.artistInfo = artistInfo;
    }

    /**
     * Getter method for albumInfo 
     * @return: string value for album info
     */
    public String getAlbumInfo() 
    {
        return albumInfo;
    }

    /**
     * Setter method for albumInfo 
     * @param albumInfo: album information
     */
    public void setAlbumInfo(String albumInfo) 
    {
        this.albumInfo = albumInfo;
    }

    /**
     * Getter method for priceInfo 
     * @return: string value for price info
     */
    public String getPriceInfo() 
    {
        return priceInfo;
    }

    /**
     * Setter method for priceInfo 
     * @param priceInfo: price information
     */
    public void setPriceInfo(String priceInfo) 
    {
        this.priceInfo = priceInfo;
    }
}