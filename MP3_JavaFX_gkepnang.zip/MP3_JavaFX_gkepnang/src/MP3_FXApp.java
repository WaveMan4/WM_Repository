/**
 * Java MP3 Player
 * @author Gilles Kepnang
 * 
 * Program Description: 
 *     This Java Program executes an MP3 player as a JavaFX Application
 *     
 */

import javafx.application.*;
import javafx.scene.*;
import javafx.stage.*;


public class MP3_FXApp extends Application
{
    private displayPanel mp3Panel;
    
    public void init ()
    {
       mp3Panel = new displayPanel("SongDB.txt");
    }
    public void start (Stage myStage)
    {
        myStage.setTitle( "MP3 PLAYER - Summer 2017 Edition" );
        //FlowPane rootNode = new FlowPane(); //Insert Custom FlowPane Here
        Scene mp3Scene = new Scene(mp3Panel, 500, 300);
        myStage.setScene(mp3Scene);
        myStage.setResizable(true);
        myStage.show();
    }

    public static void main (String [] args)
    {
        launch(args);
    }
}
