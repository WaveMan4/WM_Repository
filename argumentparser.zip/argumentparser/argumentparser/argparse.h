//Name: Gilles Kepnang

#ifndef ARGPARSE_H
#define ARGPARSE_H

#include <argumentdescriptor.h>
#include <argumentresult.h>
#include <argumentparser.h>
#include <QDebug>
#endif // ARGPARSE_H
